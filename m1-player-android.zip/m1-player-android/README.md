# M1 Player

M1 Player is a Kotlin Android Studio music player for local audio files, with YouTube Data API search, an Adsterra banner slot, and Firebase Remote Config update checks.

## Open in Android Studio

1. Open the `m1-player-android` folder.
2. Let Android Studio sync the Gradle project.
3. Copy `local.properties.example` to `local.properties`.
4. Add a restricted YouTube Data API key to `local.properties`.
5. Add an Adsterra banner URL to `ADSTERRA_BANNER_URL` when your Adsterra unit is ready.
6. For Firebase updates, add the `google-services.json` file from your Firebase Android app to `app/google-services.json`.
7. Run the `app` configuration on an Android 8.0+ device or emulator.

`local.properties` and `google-services.json` are intentionally ignored so API keys and Firebase configuration are not committed.

## YouTube Data API

The app calls the YouTube Data API v3 search endpoint and opens selected results in the YouTube app or browser. It does not download or re-host YouTube media.

Create an API key in Google Cloud, enable **YouTube Data API v3**, and restrict the key to the APIs and Android app package you use. Put it in `local.properties`:

```properties
YOUTUBE_API_KEY=your-restricted-key
```

## Adsterra

Adsterra banner inventory is rendered through the `AdsterraBanner` WebView component. Set:

```properties
ADSTERRA_BANNER_URL=https://your-hosted-banner-page.example/banner.html
```

The starter app shows a configuration hint instead of loading an empty WebView when this value is blank. Replace the URL with the hosted banner page or endpoint supplied by your Adsterra setup.

## Firebase Remote Config

After adding `google-services.json`, create these Remote Config parameters:

- `minimum_supported_version_code` — number; the minimum app version allowed to continue using the app.
- `update_url` — string; the Uptodown release URL.

If the remote minimum version is higher than the installed version, M1 Player shows an update dialog with an **Open Uptodown** action. Defaults are included so the app remains usable when Firebase is not configured yet.

## Release checklist

- Replace the package-specific Firebase file with the production Firebase app configuration.
- Keep the YouTube API key restricted to `com.m1.player` and the release signing certificate.
- Configure the final Uptodown listing URL.
- Configure the Adsterra unit and verify its policy requirements before publishing.
- Update `versionCode` and `versionName` in `app/build.gradle.kts`.