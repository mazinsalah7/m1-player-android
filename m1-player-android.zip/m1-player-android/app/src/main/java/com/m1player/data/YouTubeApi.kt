package com.m1player.data

import com.m1player.BuildConfig
import com.m1player.model.YouTubeResult
import com.m1player.model.YouTubeSearchResponse
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

private interface YouTubeService {
    @GET("youtube/v3/search")
    suspend fun search(
        @Query("part") part: String = "snippet",
        @Query("q") query: String,
        @Query("type") type: String = "video",
        @Query("maxResults") maxResults: Int = 10,
        @Query("key") apiKey: String,
    ): YouTubeSearchResponse
}

class YouTubeRepository {
    private val service: YouTubeService = Retrofit.Builder()
        .baseUrl("https://www.googleapis.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(YouTubeService::class.java)

    suspend fun search(query: String): Result<List<YouTubeResult>> {
        if (BuildConfig.YOUTUBE_API_KEY.isBlank()) {
            return Result.failure(IllegalStateException("YouTube API key is not configured"))
        }

        return runCatching {
            service.search(query = query.trim(), apiKey = BuildConfig.YOUTUBE_API_KEY).items
                .filter { !it.id.videoId.isNullOrBlank() }
                .map {
                    YouTubeResult(
                        videoId = it.id.videoId.orEmpty(),
                        title = it.snippet.title,
                        channelTitle = it.snippet.channelTitle,
                        thumbnailUrl = it.snippet.thumbnails.default.url,
                    )
                }
        }
    }
}