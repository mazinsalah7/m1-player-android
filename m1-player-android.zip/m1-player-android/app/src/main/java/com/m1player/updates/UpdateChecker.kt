package com.m1player.updates

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.m1player.BuildConfig

data class UpdateInfo(
    val minimumVersionCode: Long,
    val updateUrl: String,
)

class UpdateChecker(private val context: Context) {
    fun checkForUpdate(onResult: (UpdateInfo?) -> Unit) {
        val firebaseApp = runCatching { FirebaseApp.initializeApp(context) }.getOrNull()
        if (firebaseApp == null) {
            onResult(null)
            return
        }

        val remoteConfig = FirebaseRemoteConfig.getInstance(firebaseApp)
        val settings = FirebaseRemoteConfigSettings.Builder()
            .setMinimumFetchIntervalInSeconds(3_600)
            .build()

        remoteConfig.setConfigSettingsAsync(settings)
        remoteConfig.setDefaultsAsync(
            mapOf(
                "minimum_supported_version_code" to BuildConfig.VERSION_CODE.toLong(),
                "update_url" to BuildConfig.UPTODOWN_URL,
            ),
        )
        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                onResult(null)
                return@addOnCompleteListener
            }

            val minimumVersion = remoteConfig.getLong("minimum_supported_version_code")
            val updateUrl = remoteConfig.getString("update_url").ifBlank { BuildConfig.UPTODOWN_URL }
            onResult(
                if (minimumVersion > BuildConfig.VERSION_CODE) {
                    UpdateInfo(minimumVersion, updateUrl)
                } else {
                    null
                },
            )
        }
    }
}