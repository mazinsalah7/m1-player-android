package com.m1player.model

import com.google.gson.annotations.SerializedName

data class YouTubeSearchResponse(
    val items: List<YouTubeSearchItem> = emptyList(),
)

data class YouTubeSearchItem(
    val id: YouTubeVideoId,
    val snippet: YouTubeSnippet,
)

data class YouTubeVideoId(
    @SerializedName("videoId") val videoId: String?,
)

data class YouTubeSnippet(
    val title: String,
    val channelTitle: String,
    val thumbnails: YouTubeThumbnails,
)

data class YouTubeThumbnails(
    @SerializedName("default") val default: YouTubeThumbnail,
)

data class YouTubeThumbnail(
    val url: String,
)

data class YouTubeResult(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val thumbnailUrl: String,
)