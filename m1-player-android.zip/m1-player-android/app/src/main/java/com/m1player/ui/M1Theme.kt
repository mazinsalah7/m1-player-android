package com.m1player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val M1Colors = darkColorScheme(
    primary = Color(0xFFB7F34A),
    onPrimary = Color(0xFF152000),
    secondary = Color(0xFF8CD5FF),
    background = Color(0xFF080A0F),
    surface = Color(0xFF10141D),
    surfaceVariant = Color(0xFF1B2230),
    onBackground = Color(0xFFF3F5F7),
    onSurface = Color(0xFFF3F5F7),
    onSurfaceVariant = Color(0xFFA8B0BE),
)

@Composable
fun M1Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = M1Colors,
        content = content,
    )
}