package com.m1player.model

import android.net.Uri

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val contentUri: Uri,
    val durationMs: Long,
)