package com.m1player

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.m1player.data.LocalMusicRepository
import com.m1player.data.YouTubeRepository
import com.m1player.model.Track
import com.m1player.model.YouTubeResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlayerUiState(
    val tracks: List<Track> = emptyList(),
    val searchResults: List<YouTubeResult> = emptyList(),
    val searchQuery: String = "",
    val isLoadingLibrary: Boolean = false,
    val isSearching: Boolean = false,
    val errorMessage: String? = null,
    val nowPlaying: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val localMusicRepository = LocalMusicRepository(application)
    private val youTubeRepository = YouTubeRepository()
    private val player = ExoPlayer.Builder(application).build()
    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()
    private var progressJob: Job? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
            }
        })

        progressJob = viewModelScope.launch {
            while (isActive) {
                _uiState.value = _uiState.value.copy(
                    positionMs = player.currentPosition.coerceAtLeast(0L),
                )
                delay(500)
            }
        }
    }

    fun loadLocalMusic() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingLibrary = true, errorMessage = null)
            runCatching { localMusicRepository.loadTracks() }
                .onSuccess { tracks ->
                    _uiState.value = _uiState.value.copy(tracks = tracks, isLoadingLibrary = false)
                }
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoadingLibrary = false,
                        errorMessage = error.message ?: "Could not read local music",
                    )
                }
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun searchYouTube() {
        val query = _uiState.value.searchQuery.trim()
        if (query.isBlank()) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSearching = true, errorMessage = null)
            youTubeRepository.search(query)
                .onSuccess { results ->
                    _uiState.value = _uiState.value.copy(
                        searchResults = results,
                        isSearching = false,
                    )
                }
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        isSearching = false,
                        errorMessage = error.message ?: "YouTube search failed",
                    )
                }
        }
    }

    fun playTrack(track: Track) {
        val current = _uiState.value.nowPlaying
        if (current?.id == track.id) {
            if (player.isPlaying) player.pause() else player.play()
            return
        }

        player.setMediaItem(MediaItem.fromUri(track.contentUri))
        player.prepare()
        player.play()
        _uiState.value = _uiState.value.copy(
            nowPlaying = track,
            isPlaying = true,
            positionMs = 0L,
        )
    }

    fun togglePlayback() {
        if (_uiState.value.nowPlaying == null) return
        if (player.isPlaying) player.pause() else player.play()
    }

    fun seekTo(positionMs: Long) {
        player.seekTo(positionMs)
        _uiState.value = _uiState.value.copy(positionMs = positionMs)
    }

    override fun onCleared() {
        progressJob?.cancel()
        player.release()
        super.onCleared()
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(application) as T
        }
    }
}